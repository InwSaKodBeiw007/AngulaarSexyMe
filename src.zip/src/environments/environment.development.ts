export const environment = {
    baseUrl: 'https://localhost:8000/'
}
