export const environment = {
    baseUrl: '/'
}
