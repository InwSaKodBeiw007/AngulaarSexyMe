export interface Photo {
    id: string,
    public_id: string,
    url: string,
    is_avatar: boolean,
    created_at: Date
}
